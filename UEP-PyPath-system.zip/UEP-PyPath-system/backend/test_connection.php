
<?php

require_once __DIR__ . '/database/connection.php';

try {
    $pdo = db();

    echo "UEP-PyPath database connected successfully!";

} catch (PDOException $e) {
    http_response_code(500);

    echo "<h3>Database Connection Error</h3>";
    echo htmlspecialchars(
        $e->getMessage(),
        ENT_QUOTES,
        'UTF-8'
    );
}
