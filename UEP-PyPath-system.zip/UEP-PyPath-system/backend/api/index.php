<?php
// Single entry point for /api routes. Apache rewrites clean URLs here.
declare(strict_types=1);
require_once __DIR__ . '/config/bootstrap.php';

$path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '', '/');
$apiPosition = strpos($path, '/api/');
$route = $apiPosition === false ? '' : substr($path, $apiPosition + 5);
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    switch ($route) {
        case 'health':
            requireMethod('GET');
            db()->query('SELECT 1');
            jsonResponse(200, ['status' => 'ok', 'database' => 'connected']);

        case 'auth/register':
            requireMethod('POST');
            $input = readJson();
            $name = trim((string)($input['fullName'] ?? ''));
            $email = strtolower(trim((string)($input['email'] ?? '')));
            $password = (string)($input['password'] ?? '');

            if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                jsonResponse(422, ['message' => 'Enter your full name and a valid email address.']);
            }
            if (strlen($password) < 8) {
                jsonResponse(422, ['message' => 'Password must contain at least 8 characters.']);
            }

            // Public sign-ups are always Students. Create Instructor accounts privately
            // through a trusted administrator/database process, never from a public form.
            $stmt = db()->prepare(
                'INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)'
            );
            try {
                $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), 'Student']);
            } catch (PDOException $error) {
                if ($error->getCode() === '23000') {
                    jsonResponse(409, ['message' => 'An account with this email already exists.']);
                }
                throw $error;
            }

            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id' => (int)db()->lastInsertId(),
                'name' => $name,
                'email' => $email,
                'role' => 'Student',
            ];
            jsonResponse(201, ['message' => 'Account created successfully.', 'user' => $_SESSION['user']]);

        case 'auth/login':
            requireMethod('POST');
            $input = readJson();
            $email = strtolower(trim((string)($input['email'] ?? '')));
            $password = (string)($input['password'] ?? '');
            $requestedRole = (string)($input['role'] ?? '');

            $stmt = db()->prepare('SELECT id, full_name, email, password_hash, role FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if (!$user || !password_verify($password, $user['password_hash'])) {
                jsonResponse(401, ['message' => 'Incorrect email or password.']);
            }
            if (in_array($requestedRole, ['Student', 'Instructor'], true) && $requestedRole !== $user['role']) {
                jsonResponse(403, ['message' => 'This account does not have the selected role.']);
            }

            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id' => (int)$user['id'],
                'name' => $user['full_name'],
                'email' => $user['email'],
                'role' => $user['role'],
            ];
            jsonResponse(200, ['message' => 'Login successful.', 'user' => $_SESSION['user']]);

        case 'auth/logout':
            requireMethod('POST');
            $_SESSION = [];
            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', $params['secure'], $params['httponly']);
            }
            session_destroy();
            jsonResponse(200, ['message' => 'Logged out successfully.']);

        case 'auth/session':
            requireMethod('GET');
            $user = requireUser();
            jsonResponse(200, ['user' => $user]);

        case 'modules':
            requireMethod('GET');
            requireUser();
            $stmt = db()->query(
                'SELECT id, title, description, module_order FROM modules
                 WHERE is_published = 1 ORDER BY module_order, id'
            );
            jsonResponse(200, ['modules' => $stmt->fetchAll()]);

        default:
            jsonResponse(404, ['message' => 'API endpoint not found.', 'route' => $route]);
    }
} catch (Throwable $error) {
    error_log('[UEP-PyPath API] ' . $error->getMessage());
    jsonResponse(500, ['message' => 'A server error occurred. Check the PHP error log.']);
}
