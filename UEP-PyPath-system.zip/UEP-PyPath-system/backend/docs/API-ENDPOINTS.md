# Current API endpoints

Base URL (default XAMPP folder):
`http://localhost/uep-pypath-system/backend/api`

| Method | Endpoint | Purpose | Access |
|---|---|---|---|
| GET | `/health` | Check PHP and MySQL connection | Public |
| POST | `/auth/register` | Register a Student | Public |
| POST | `/auth/login` | Log in | Public |
| POST | `/auth/logout` | End current session | Session |
| GET | `/auth/session` | Return current logged-in user | Session |
| GET | `/modules` | List published modules | Session |

### Register JSON body

```json
{
  "fullName": "Student Name",
  "email": "student@example.com",
  "password": "minimum-eight-characters",
  "role": "Student"
}
```

### Login JSON body

```json
{
  "email": "student@example.com",
  "password": "your-password",
  "role": "Student"
}
```

The API deliberately does not accept public Instructor role assignment.
