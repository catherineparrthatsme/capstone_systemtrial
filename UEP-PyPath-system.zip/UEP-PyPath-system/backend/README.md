# UEP-PyPath PHP Backend (Starter)

This backend is designed for the existing HTML/CSS/JavaScript frontend. It uses PHP sessions and MySQL with PDO.

## Included in this first backend stage

- MySQL schema for users, modules, lessons, lesson resources, assessments, questions, and student progress.
- `GET /api/health` to verify PHP and MySQL connectivity.
- `POST /api/auth/register` to create a Student account.
- `POST /api/auth/login` to authenticate an account.
- `POST /api/auth/logout` to end the PHP session.
- `GET /api/auth/session` to check the current session.
- `GET /api/modules` to return published modules for a logged-in user.

No fake modules, lessons, student accounts, or progress records are inserted.

## Setup with XAMPP

1. Copy the `UEP-PyPath-system` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** in XAMPP.
3. Open `http://localhost/phpmyadmin`.
4. Import `backend/database/uep_pypath.sql`.
5. Open `backend/api/config/database.php` and set the MySQL username/password to match your local XAMPP setup.
6. Keep the frontend API setting in `frontend/js/config.js` as:
   `http://localhost/UEP-PyPath-system/backend/api`
   (If your folder name or placement differs, update this URL.)
7. Open `http://localhost/UEP-PyPath-system/frontend/index.html`.

## Test the backend

Open this URL in your browser:

`http://localhost/UEP-PyPath-system/backend/api/health`

Expected response when the database is connected:

```json
{"status":"ok","database":"connected"}
```

If you get a 404, make sure Apache's `mod_rewrite` is enabled and `.htaccess` overrides are allowed. The API also includes a fallback `index.php` route; you can test it directly by opening `index.php?route=health` only after adapting the router for query routing, or use the clean `/health` route with rewrite enabled.

## Authentication notes

- Passwords are stored using PHP `password_hash()` and checked with `password_verify()`.
- SQL statements use PDO prepared statements.
- Authentication is stored in a PHP server-side session; the frontend must send `credentials: "include"`.
- Public registration always creates a Student account. The public role selector is not trusted for assigning Instructor privileges. Create instructor accounts through a trusted admin process after the initial setup.
- For production deployment, use HTTPS, configure secure session cookies, restrict instructor account creation, and add CSRF protection.

## Current scope

This is the first backend foundation, not the complete learning system yet. The next stage is to build instructor content-management endpoints and student endpoints for lessons, resources, assessments, and progress, then connect the existing dashboard views without changing their design.
