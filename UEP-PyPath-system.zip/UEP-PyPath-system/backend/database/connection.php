
<?php

// Reusable database connection for UEP-PyPath.
function db(): PDO
{
    static $pdo = null;

    // Reuse the existing connection if already connected.
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    // MySQL database configuration.
    $host = '127.0.0.1';
    $port = '3306';
    $database = 'uep_pypath';
    $username = 'root';
    $password = 'Cagaca.06';
    $charset = 'utf8mb4';

    // Create the PDO connection.
    $dsn = "mysql:host={$host};port={$port};dbname={$database};charset={$charset}";

    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    return $pdo;
}
