// AUTHENTICATION PAGE SCRIPT
// The same script is used by login.html and signup.html. It detects the current page
// from the URL, then renders the correct form and connects its events to the PHP API.
const authRoot = document.getElementById("auth-app");
const isSignupPage = window.location.pathname.endsWith("signup.html");

const iconCode = `
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="16 18 22 12 16 6"></polyline>
        <polyline points="8 6 2 12 8 18"></polyline>
    </svg>
`;
const eyeIcon = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"></path>
        <circle cx="12" cy="12" r="3"></circle>
    </svg>
`;

// ROLE SELECTOR
// Creates the Student/Instructor choice. The selected role is included in the API request.
function roleButton(role, selected, signup = false) {
    const icon = role === "Student"
        ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>'
        : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M20 8v6m3-3h-6"/></svg>';
    if (signup) {
        return `<button type="button" class="role-card${selected ? " active" : ""}" data-role="${role}" aria-pressed="${selected}">
            <span class="role-card-icon${selected ? " active" : ""}">${icon}</span>${role}
        </button>`;
    }
    return `<button type="button" class="role-switch-option${selected ? " active" : ""}" data-role="${role}" aria-pressed="${selected}">
        ${icon}${role}
    </button>`;
}

// FORM RENDERING
// Builds the login or registration form. The page-specific HTML file provides the
// mount point, while CSS controls the visual appearance.
function renderAuth() {
    const role = "Student";
    authRoot.innerHTML = `
        <div class="auth-shell">
            <a href="index.html" class="auth-brand self-start border-0 bg-transparent p-0" aria-label="Back to homepage">
                <span class="auth-brand-mark">${iconCode}</span>
                <span class="auth-brand-name">UEP-<span class="text-lime-500">PyPath</span></span>
            </a>
            <div class="auth-center">
                <form class="auth-card${isSignupPage ? " auth-card-wide" : ""}" id="auth-form">
                    <h1 class="auth-title">${isSignupPage ? "Sign Up" : "Welcome Back!"}</h1>
                    <p class="auth-subtitle">${isSignupPage ? "Join UEP-PyPath as a student or an instructor." : "Log in to continue your learning journey."}</p>
                    ${isSignupPage ? `
                        <div class="mt-5">
                            <label class="field-label" for="full-name">Full Name</label>
                            <input id="full-name" name="fullName" required class="form-field auth-input" placeholder="Juan Dela Cruz" autocomplete="name">
                        </div>
                        <div class="mt-4">
                            <label class="field-label" for="email">Email Address</label>
                            <input id="email" name="email" type="email" required class="form-field auth-input" placeholder="you@gmail.com" autocomplete="email">
                        </div>
                        <div class="grid md:grid-cols-2 gap-4 mt-4">
                            <div>
                                <label class="field-label" for="password">Password</label>
                                <div class="relative">
                                    <input id="password" name="password" type="password" minlength="8" required class="form-field auth-input pr-10" placeholder="At least 8 characters">
                                    <button type="button" class="password-toggle" data-toggle="password" aria-label="Show password">${eyeIcon}</button>
                                </div>
                            </div>
                            <div>
                                <label class="field-label" for="confirm-password">Confirm Password</label>
                                <div class="relative">
                                    <input id="confirm-password" name="confirmPassword" type="password" minlength="8" required class="form-field auth-input pr-10" placeholder="Re-enter your password">
                                    <button type="button" class="password-toggle" data-toggle="confirm-password" aria-label="Show confirm password">${eyeIcon}</button>
                                </div>
                            </div>
                        </div>
                        <span class="field-label mt-4">Register As</span>
                        <div class="grid grid-cols-2 gap-4" id="role-options">
                            ${roleButton("Student", true, true)}
                            ${roleButton("Instructor", false, true)}
                        </div>
                    ` : `
                        <span class="field-label mt-5">Log in as</span>
                        <div class="role-switch" role="group" aria-label="Log in as" id="role-options">
                            ${roleButton("Student", true)}
                            ${roleButton("Instructor", false)}
                        </div>
                        <div class="mt-4">
                            <label class="field-label" for="email">Email</label>
                            <input id="email" name="email" type="email" required class="form-field auth-input" placeholder="Enter your email" autocomplete="email">
                        </div>
                        <div class="mt-4">
                            <label class="field-label" for="password">Password</label>
                            <div class="relative">
                                <input id="password" name="password" type="password" required class="form-field auth-input pr-10" placeholder="Enter your password" autocomplete="current-password">
                                <button type="button" class="password-toggle" data-toggle="password" aria-label="Show password">${eyeIcon}</button>
                            </div>
                        </div>
                        <label class="remember-row">
                            <input type="checkbox" name="remember">
                            Remember Me
                        </label>
                    `}
                    <div id="auth-error" class="toast" role="alert"></div>
                    <button type="submit" class="auth-submit${isSignupPage ? " mt-6" : ""}">${isSignupPage ? "Sign Up" : "Log In"}</button>
                    <p class="auth-footer">
                        ${isSignupPage ? "Already have an account?" : "Don't have an account?"}
                        <a class="auth-link" href="${isSignupPage ? "login.html" : "signup.html"}">${isSignupPage ? "Log In" : "Sign Up"}</a>
                    </p>
                </form>
            </div>
        </div>
    `;
    bindAuth();
}

// FORM BEHAVIOR AND API REQUESTS
// Handles role selection, show/hide password buttons, basic form validation,
// and POST requests to /auth/login or /auth/register.
function bindAuth() {
    let selectedRole = "Student";
    document.querySelectorAll("[data-role]").forEach((button) => {
        button.addEventListener("click", () => {
            selectedRole = button.dataset.role;
            document.querySelectorAll("[data-role]").forEach((item) => {
                const active = item.dataset.role === selectedRole;
                item.classList.toggle("active", active);
                item.setAttribute("aria-pressed", String(active));
                const icon = item.querySelector(".role-card-icon");
                if (icon) icon.classList.toggle("active", active);
            });
        });
    });

    document.querySelectorAll("[data-toggle]").forEach((button) => {
        button.addEventListener("click", () => {
            const input = document.getElementById(button.dataset.toggle);
            input.type = input.type === "password" ? "text" : "password";
            button.setAttribute("aria-label", input.type === "password" ? "Show password" : "Hide password");
        });
    });

    document.getElementById("auth-form").addEventListener("submit", async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const values = Object.fromEntries(new FormData(form).entries());
        const errorBox = document.getElementById("auth-error");
        errorBox.className = "toast";
        errorBox.textContent = "";

        if (isSignupPage && values.password !== values.confirmPassword) {
            showError("Both passwords need to match.");
            return;
        }
        if (isSignupPage && values.password.length < 8) {
            showError("Your password must be at least 8 characters.");
            return;
        }

        // Choose the PHP endpoint according to the current page.
        const endpoint = isSignupPage ? "/auth/register" : "/auth/login";
        const apiBase = window.PYPATH_CONFIG?.API_BASE_URL || "";

        try {
            const response = await fetch(`${apiBase}${endpoint}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({
                    fullName: values.fullName || "",
                    email: values.email,
                    password: values.password,
                    role: selectedRole,
                    remember: Boolean(values.remember)
                })
            });
            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.message || "Unable to complete the request.");
            }
            sessionStorage.setItem("pypath_role", result.user?.role || selectedRole);
            sessionStorage.setItem("pypath_name", result.user?.name || values.fullName || "");
            sessionStorage.setItem("pypath_email", result.user?.email || values.email || "");
            window.location.href = "dashboard.html";
        } catch (error) {
            showError(error.message || "Unable to connect to the PHP backend. Check your API configuration.");
        }

        function showError(message) {
            errorBox.textContent = message;
            errorBox.className = "toast show error";
        }
    });
}

renderAuth();
