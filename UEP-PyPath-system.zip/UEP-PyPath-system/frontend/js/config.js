// API CONFIGURATION
// Set this URL to the root of your PHP API. auth.js and dashboard.js read it
// when sending requests, so you only need to update the address in this file.

window.PYPATH_CONFIG = {
    API_BASE_URL: "http://localhost/uep-pypath/api"
};
