// DASHBOARD APPLICATION
// This script builds the dashboard shell, sidebar navigation, and page content.
// It intentionally does not include sample learner or course records.
const dashboardRoot = document.getElementById("dashboard-app");

// Sidebar items available to students and instructors.
// Each item contains: view ID, visible label, and icon key.
const studentNavigation = [
    ["student-home", "Dashboard", "grid"],
    ["student-modules", "Learning Modules", "book"],
    ["student-videos", "Instructional Videos", "video"],
    ["student-assessments", "Assessment", "check"],
    ["student-progress", "My Progress", "trend"],
    ["profile", "Manage Profile", "user"]
];

const instructorNavigation = [
    ["instructor-home", "Dashboard", "grid"],
    ["students", "Student Progress", "users"],
    ["profile", "Manage Profile", "settings"]
];

const iconSvg = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 5.5v16M8 7h8M8 11h8"/>',
    video: '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="m17 10 4-3v10l-4-3z"/>',
    check: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="m8 10 2 2 5-5M8 16h8"/>',
    trend: '<path d="m3 17 6-6 4 4 8-9"/><path d="M15 6h6v6"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M20 8v6m3-3h-6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.6a8 8 0 0 1-1.7 1l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.7-1l-1.7.6-1.4-2.4 1.4-1.1a8 8 0 0 1 0-2l-1.4-1.1 1.4-2.4 1.7.6a8 8 0 0 1 1.7-1l.3-1.8h2.8l.3 1.8a8 8 0 0 1 1.7 1l1.7-.6 1.4 2.4-1.4 1.1a8 8 0 0 1 0 2Z"/>',
    logout: '<path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7"/>',
    code: '<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>'
};

function icon(name, size = 16) {
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconSvg[name] || ""}</svg>`;
}

function emptyState(title, description) {
    return `<div class="dashboard-empty"><strong>${title}</strong>${description}</div>`;
}

function getRole() {
    return sessionStorage.getItem("pypath_role") || "Student";
}

function getName() {
    return sessionStorage.getItem("pypath_name") || "";
}

function getEmail() {
    return sessionStorage.getItem("pypath_email") || "";
}

// DASHBOARD SHELL
// Creates the sidebar and topbar once. Clicking a navigation item calls showView()
// to replace the content area without navigating to another HTML file.
function renderShell() {
    const role = getRole();
    const isInstructor = role === "Instructor";
    const navigation = isInstructor ? instructorNavigation : studentNavigation;

    dashboardRoot.innerHTML = `
        <div class="app-shell">
            <aside class="side-nav" aria-label="Application navigation">
                <div class="flex items-center gap-2 px-1">
                    <div class="brand-mark">${icon("code", 17)}</div>
                    <div class="brand-name">
                        UEP-PyPath
                        <div class="brand-sub font-sans text-[8px] font-normal text-slate-400 tracking-normal mt-0.5">Learn. Build. Master.</div>
                    </div>
                </div>
                <p class="nav-caption">${isInstructor ? "INSTRUCTOR SPACE" : "LEARNER SPACE"}</p>
                <nav class="mt-5 space-y-1" id="dashboard-navigation">
                    ${navigation.map(([id, label, iconName], index) => `
                        <button type="button" class="nav-link${index === 0 ? " active" : ""}" data-view="${id}">
                            ${icon(iconName)}
                            <span>${label}</span>
                        </button>
                    `).join("")}
                </nav>
                <button type="button" class="nav-link mt-auto" id="logout-button">
                    ${icon("logout")}<span>Log Out</span>
                </button>
            </aside>
            <div class="workspace">
                <header class="topbar">
                    <div class="flex items-center gap-2">
                        <div class="avatar" id="user-avatar">${getName().trim().split(/\s+/).map(part => part[0] || "").slice(0,2).join("").toUpperCase()}</div>
                        <div class="hide-mobile leading-tight">
                            <div class="font-bold text-[11px]" id="user-name">${getName()}</div>
                            <div class="text-[9px] text-slate-400">${role}</div>
                        </div>
                    </div>
                </header>
                <main class="page-area" id="dashboard-content"></main>
            </div>
        </div>
    `;

    document.getElementById("dashboard-navigation").addEventListener("click", (event) => {
        const button = event.target.closest("[data-view]");
        if (!button) return;
        showView(button.dataset.view);
    });

    document.getElementById("logout-button").addEventListener("click", logout);
    showView(isInstructor ? "instructor-home" : "student-home");
}

// Metric card layout. The value is shown as a dash until real database data is connected.
function metricCard(iconName, iconClass, label) {
    return `
        <article class="metric-card">
            <div class="metric-icon ${iconClass}">${icon(iconName, 16)}</div>
            <div class="metric-label">${label}</div>
            <div class="metric-value metric-placeholder">—</div>
        </article>
    `;
}

// STUDENT OVERVIEW
// The card layout follows the supplied design. Values remain blank instead of using
// fabricated statistics until the PHP backend returns real student data.
function studentHome() {
    return `
        <section class="view active">
            <div class="flex flex-wrap items-end justify-between gap-3">
                <div>
                    <p class="eyebrow">WELCOME BACK</p>
                    <h1>Hello, ${getName().trim() ? escapeHtml(getName().split(" ")[0]) : "Learner"}!</h1>
                    <p class="subcopy">Keep building your Python knowledge—one concept at a time.</p>
                </div>
            </div>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                ${metricCard("trend", "bg-lime-50 text-lime-500", "Current streak")}
                ${metricCard("book", "bg-blue-50 text-blue-500", "Lessons done")}
                ${metricCard("check", "bg-amber-50 text-amber-500", "Best score")}
            </div>
            <div class="mt-4 max-w-2xl">
                <article class="surface p-5">
                    <div class="flex items-start justify-between">
                        <div>
                            <p class="eyebrow">PICK UP WHERE YOU LEFT OFF</p>
                            <h2 class="text-[16px] font-bold tracking-tight">Continue your learning</h2>
                            <p class="small-note">Your next lesson will appear here when available.</p>
                        </div>
                        <div class="metric-icon bg-lime-50 text-lime-500">${icon("book", 16)}</div>
                    </div>
                    ${emptyState("No learning activity yet", "Your modules and lesson progress will appear here after they are loaded from the database.")}
                </article>
            </div>
        </section>
    `;
}

// INSTRUCTOR OVERVIEW
// Instructor summary cards are placeholders until real class data is fetched.
function instructorHome() {
    return `
        <section class="view active">
            <p class="eyebrow">INSTRUCTOR OVERVIEW</p>
            <h1>Dashboard</h1>
            <p class="subcopy">Monitor your Object-Oriented Programming class.</p>
            <div class="grid grid-cols-2 lg:grid-cols-3 gap-3">
                ${metricCard("users", "bg-blue-50 text-blue-500", "Students enrolled")}
                ${metricCard("trend", "bg-lime-50 text-lime-500", "Average class progress")}
                ${metricCard("check", "bg-amber-50 text-amber-500", "Assessments completed")}
            </div>
            <article class="surface p-5 mt-4">
                <h2 class="text-[15px] font-bold">Class learning insight</h2>
                ${emptyState("No class data available", "Class insights will appear when actual student activity is retrieved from the database.")}
            </article>
        </section>
    `;
}

// MODULES PAGE
// Empty state is intentional: actual modules should be loaded from the PHP API.
function modulesView() {
    return `
        <section class="view active">
            <p class="eyebrow">YOUR LEARNING JOURNEY</p>
            <h1>Learning Modules</h1>
            <p class="subcopy">Master Python step by step with guided modules and interactive lessons.</p>
            <div class="space-y-3">${emptyState("No modules available", "Learning modules and lessons will appear here when loaded from your database.")}</div>
        </section>
    `;
}

// INSTRUCTIONAL VIDEOS PAGE
// Actual video records and URLs should be retrieved from the database/API.
function videosView() {
    return `
        <section class="view active">
            <p class="eyebrow">INSTRUCTIONAL VIDEOS</p>
            <h1>Instructional Videos</h1>
            <p class="subcopy"></p>
            <div class="grid lg:grid-cols-2 gap-4 video-empty-space">
                ${emptyState("No videos available", "Instructional videos will appear here when actual video records are available.")}
            </div>
        </section>
    `;
}

// ASSESSMENTS PAGE
// Do not hardcode assessment questions here. Load them from the backend when ready.
function assessmentsView() {
    return `
        <section class="view active">
            <p class="eyebrow">CHECK YOUR UNDERSTANDING</p>
            <h1>Assessment</h1>
            <p class="subcopy">Test your knowledge with learning assessments.</p>
            <div class="surface p-6 assessment-empty-space">
                ${emptyState("No assessments available", "Assessment activities will be loaded from the database.")}
            </div>
        </section>
    `;
}

// LEARNING PROGRESS PAGE
// Progress indicators must be calculated from completed lessons and assessment results.
function progressView() {
    return `
        <section class="view active">
            <p class="eyebrow">YOUR LEARNING JOURNEY</p>
            <h1>Learning Progress</h1>
            <p class="subcopy">Celebrate every concept mastered and keep moving forward.</p>
            <div class="grid lg:grid-cols-[2fr_1fr] gap-4">
                <article class="surface p-5">
                    <h2 class="text-[15px] font-bold">Overall course completion</h2>
                    <div class="progress-track mt-3"><div class="progress-fill" style="width:0%"></div></div>
                    ${emptyState("No progress data yet", "Your course completion will be calculated from actual completed lessons and assessments.")}
                </article>
                <article class="surface p-5">
                    <div class="metric-icon bg-amber-50 text-amber-500">${icon("check", 16)}</div>
                    <p class="metric-label">Latest assessment</p>
                    <div class="metric-value metric-placeholder">—</div>
                    <p class="small-note">No assessment results yet.</p>
                </article>
            </div>
        </section>
    `;
}

// INSTRUCTOR STUDENT TABLE
// The table is empty until student records are fetched from the backend.
function studentsView() {
    return `
        <section class="view active">
            <p class="eyebrow">CLASS ANALYTICS</p>
            <h1>Student Progress</h1>
            <div class="surface mt-4 table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>STUDENT</th>
                            <th>MODULE PROGRESS</th>
                            <th>ASSESSMENTS COMPLETED</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
                ${emptyState("No student records available", "Student records will appear here after they are retrieved from the database.")}
            </div>
        </section>
    `;
}

// PROFILE PAGE
// Profile fields are displayed here. A PHP profile endpoint is needed to load/save them.
function profileView() {
    return `
        <section class="view active">
            <p class="eyebrow">ACCOUNT SETTINGS</p>
            <h1>Manage Profile</h1>
            <form class="surface p-5 mt-5 profile-form" id="profile-form">
                <div class="flex items-center gap-4 pb-5 border-b border-slate-100">
                    <div class="profile-photo-placeholder" id="profile-initials">?</div>
                    <div>
                        <b class="text-[13px]">${escapeHtml(getName()) || "Account profile"}</b>
                        <p class="small-note">${escapeHtml(getEmail())}</p>
                    </div>
                </div>
                <div class="grid md:grid-cols-2 gap-3 mt-5">
                    <div>
                        <label class="field-label" for="first-name">First name</label>
                        <input id="first-name" name="firstName" class="form-field" required>
                    </div>
                    <div>
                        <label class="field-label" for="last-name">Last name</label>
                        <input id="last-name" name="lastName" class="form-field" required>
                    </div>
                </div>
                <div class="mt-3">
                    <label class="field-label" for="profile-email">Email</label>
                    <input id="profile-email" name="email" type="email" class="form-field" value="${escapeHtml(getEmail())}" required>
                </div>
                <div id="profile-message" class="toast" role="status"></div>
                <button class="btn-primary mt-4" type="submit">Save changes</button>
            </form>
        </section>
    `;
}

function escapeHtml(value) {
    return String(value || "").replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[char]);
}

const viewRenderers = {
    "student-home": studentHome,
    "instructor-home": instructorHome,
    "student-modules": modulesView,
    "student-videos": videosView,
    "student-assessments": assessmentsView,
    "student-progress": progressView,
    "students": studentsView,
    "profile": profileView
};

// VIEW SWITCHING
// Renders the selected section and updates the active sidebar highlight.
function showView(viewId) {
    const renderer = viewRenderers[viewId] || studentHome;
    document.getElementById("dashboard-content").innerHTML = renderer();

    document.querySelectorAll("[data-view]").forEach((button) => {
        button.classList.toggle("active", button.dataset.view === viewId);
    });

    const profileForm = document.getElementById("profile-form");
    if (profileForm) {
        profileForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            const message = document.getElementById("profile-message");
            message.textContent = "Connect your PHP profile-update endpoint to save changes.";
            message.className = "toast show error";
        });
    }
}

// LOGOUT
// Requests server-side session termination, then returns the user to the login page.
async function logout() {
    const apiBase = window.PYPATH_CONFIG?.API_BASE_URL || "";
    try {
        await fetch(`${apiBase}/auth/logout`, {
            method: "POST",
            credentials: "include"
        });
    } catch (error) {
        // Clear the local UI session even if the backend is unavailable.
    }
    sessionStorage.removeItem("pypath_role");
    sessionStorage.removeItem("pypath_name");
    sessionStorage.removeItem("pypath_email");
    window.location.href = "login.html";
}

// SECURITY NOTE
// The server must protect dashboard pages and API data using a real PHP session.
// Frontend navigation alone does not secure private information.
// Initial dashboard startup:
//dashboard pages and API data using a real PHP session.
renderShell();
