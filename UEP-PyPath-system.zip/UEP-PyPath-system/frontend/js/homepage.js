// HOMEPAGE RENDERING
// This script creates the homepage markup inside the #homepage element in index.html.
// The links and buttons navigate to the separate login/signup pages or scroll to sections.
const homepageRoot = document.getElementById("homepage");

homepageRoot.innerHTML = `
    <div class="landing" id="home">
        <header class="landing-nav">
            <button type="button" class="landing-brand" aria-label="UEP-PyPath home">
                <span class="landing-brand-mark">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                </span>
                <span class="landing-brand-name">UEP-<span style="color:#58cc02">PyPath</span></span>
            </button>
            <nav aria-label="Main" class="hidden md:flex items-center gap-7">
                <button type="button" class="landing-link" data-scroll="home">Home</button>
                <button type="button" class="landing-link" data-scroll="features">Features</button>
                <button type="button" class="landing-link" data-scroll="about">About</button>
            </nav>
            <div class="flex items-center gap-2">
                <a class="landing-login" href="login.html">Login</a>
                <a class="btn-duo px-4 py-2 text-[13px]" href="signup.html">Sign Up</a>
            </div>
        </header>
        <main class="flex-1">
            <section id="features" class="flex flex-col items-center text-center px-6 pt-20 pb-28 md:pt-24 md:pb-36">
                <span class="hero-pill">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2L12 3Z"/><path d="m19 14 1.2 3.1L23 18l-2.8 1-1.2 3-1.1-3-2.9-1 2.9-.9L19 14Z"/></svg>
                    Learn Python OOP the fun way
                </span>
                <h1 class="hero-title mt-5 max-w-4xl">
                    Learn Object-Oriented Programming in Python the
                    <span style="color:#58cc02">Interactive Way</span>
                </h1>
                <p class="mt-7 max-w-2xl text-[16px] leading-relaxed text-[#777]">
                    Study lessons, watch instructional videos, answer engaging activities, and monitor
                    your progress — all in one friendly platform built for BSIT students.
                </p>
                <div class="mt-8 flex flex-wrap items-center justify-center gap-4">
                    <a class="btn-duo px-6 py-3 text-[14px]" href="signup.html">
                        Get Started
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                    </a>
                    <button type="button" class="btn-duo-ghost px-6 py-3 text-[14px]" data-scroll="about">Learn More</button>
                </div>
            </section>
        </main>
        <footer id="about" class="landing-footer">
            <div class="mx-auto grid max-w-6xl gap-10 px-6 py-12 md:grid-cols-[1fr_2fr]">
                <div>
                    <div class="flex items-center gap-2">
                        <span class="landing-brand-mark">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                        </span>
                        <span class="text-[17px] font-black text-white">UEP-<span style="color:#58cc02">PyPath</span></span>
                    </div>
                    <p class="mt-4 max-w-xs text-[13px] leading-relaxed text-[#cfcfcf]">
                        An interactive web-based learning system for Object-Oriented Programming in Python,
                        built for BSIT students.
                    </p>
                    <div class="mt-5 flex gap-3">
                        <a href="#" aria-label="Facebook" class="social-btn">f</a>
                        <a href="#" aria-label="Twitter" class="social-btn">𝕏</a>
                        <a href="#" aria-label="Instagram" class="social-btn">◎</a>
                        <a href="#" aria-label="YouTube" class="social-btn">▶</a>
                    </div>
                </div>
                <div>
                    <h2 class="text-[14px] font-extrabold text-white">University</h2>
                    <ul class="mt-4 space-y-1.5 text-[13px] text-[#cfcfcf]">
                        <li>University of Eastern Philippines</li>
                        <li>College of Science</li>
                        <li>Department of Information Technology</li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
`;

// HOMEPAGE SECTION NAVIGATION
// Buttons with data-scroll smoothly move the visitor to the matching section ID.
document.querySelectorAll("[data-scroll]").forEach((button) => {
    button.addEventListener("click", () => {
        document.getElementById(button.dataset.scroll)?.scrollIntoView({
            behavior: "smooth"
        });
    });
});
