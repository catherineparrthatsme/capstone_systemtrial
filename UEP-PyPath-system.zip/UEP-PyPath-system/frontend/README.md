# UEP-PyPath — Vanilla HTML, CSS and JavaScript

This version follows the requested multi-page folder structure while retaining the visual language and component styling from the supplied original React/Tailwind project.

## Folder structure

```text
UEP-PyPath/
├── index.html
├── login.html
├── signup.html
├── dashboard.html
├── css/
│   ├── base.css
│   ├── homepage.css
│   ├── login.css
│   ├── signup.css
│   ├── dashboard.css
│   ├── modules.css
│   ├── videos.css
│   ├── assessments.css
│   ├── progress.css
│   └── profile.css
├── js/
│   ├── config.js
│   ├── homepage.js
│   ├── auth.js
│   └── dashboard.js
└── assets/
```

## Design preservation

The original DM Sans, Nunito and Space Mono typography, green/blue/purple palette, sidebar, topbar, cards, buttons, role selector, login/sign-up card styling, and responsive Tailwind utility layouts are retained from the source design. No React or TypeScript source is used in this frontend.

The project uses the Tailwind CDN to preserve the original Tailwind utility classes without a React/Vite build. Internet access is required for the CDN and Google Fonts. All authored CSS files use vertical formatting (one declaration per line).

## Dummy data

No sample learner records, module records, video records, assessment questions, or fabricated progress are included. Their dashboard areas use empty states styled to fit the original interface.

## PHP backend

Set `API_BASE_URL` in `js/config.js` to your PHP API base URL. The auth page currently sends:
- `POST /auth/login`
- `POST /auth/register`

The logout button sends:
- `POST /auth/logout`

The login/register API should return JSON. On success, an optional `user` object with `name`, `email`, and `role` is used for the dashboard header. Review the endpoint paths and response mapping to match your PHP backend.

The dashboard is a frontend shell. Protect it on the server and connect real PHP GET/POST endpoints before using it with actual users. Client-side code is not a security boundary.


## How the code works

1. **HTML files** provide the page entry points and link the required CSS and JavaScript.
2. **CSS files** control the appearance. `base.css` contains shared styles; page/feature styles are separated so changes are easier to locate.
3. **JavaScript files** control behavior:
   - `homepage.js` renders the homepage content and handles smooth section links.
   - `auth.js` renders login or sign-up based on which HTML page loaded it, validates the form, and calls the PHP API.
   - `dashboard.js` builds the sidebar and topbar, switches dashboard sections, and displays empty states where database content is not connected.
   - `config.js` stores the PHP API base URL in one place.
4. **Assets** stores image files used by the interface.

Comments have been added throughout the source files to explain the purpose of major sections and functions. Search for comments such as `// FORM BEHAVIOR AND API REQUESTS` or `/* DASHBOARD STYLES */` to understand where to make changes.

## Important backend note

The current frontend is not a complete backend integration. It does not contain dummy data. Connect the PHP endpoints for modules, videos, assessments, progress, student records, and profile data before those dashboard pages can show live information. The PHP server must enforce authentication and authorization.
